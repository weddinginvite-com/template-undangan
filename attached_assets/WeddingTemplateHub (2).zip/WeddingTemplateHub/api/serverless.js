// This file is used to create a serverless function for the Express app
const { createServer } = require('http');
const express = require('express');
const { parse } = require('url');

// Import the Express app
const app = require('../server');

module.exports = (req, res) => {
  // Pass the request and response to the Express app
  return app(req, res);
};