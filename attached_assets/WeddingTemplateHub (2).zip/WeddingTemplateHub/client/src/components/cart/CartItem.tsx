import { useState } from 'react';
import { CartItem as CartItemType } from '@shared/schema';
import { useCart } from '@/context/CartContext';
import { formatCurrency } from '@/lib/utils';

interface CartItemProps {
  item: CartItemType;
}

const CartItem = ({ item }: CartItemProps) => {
  const { updateQuantity, removeFromCart } = useCart();
  
  const handleIncrease = () => {
    updateQuantity(item.id, item.quantity + 1);
  };
  
  const handleDecrease = () => {
    if (item.quantity > 1) {
      updateQuantity(item.id, item.quantity - 1);
    } else {
      removeFromCart(item.id);
    }
  };
  
  const handleRemove = () => {
    removeFromCart(item.id);
  };

  return (
    <div className="flex justify-between items-center border-b pb-4">
      <div className="flex-1">
        <h4 className="font-medium text-secondary">{item.name}</h4>
        <div className="flex items-center mt-1">
          <button 
            className="w-6 h-6 flex items-center justify-center bg-gray-100 rounded"
            onClick={handleDecrease}
            aria-label="Decrease quantity"
          >
            -
          </button>
          <span className="mx-2">{item.quantity}</span>
          <button 
            className="w-6 h-6 flex items-center justify-center bg-gray-100 rounded"
            onClick={handleIncrease}
            aria-label="Increase quantity"
          >
            +
          </button>
        </div>
      </div>
      
      <div className="text-right">
        <span className="font-medium text-primary">{formatCurrency(item.price * item.quantity)}</span>
        <button 
          className="block text-red-500 text-sm mt-1"
          onClick={handleRemove}
        >
          Hapus
        </button>
      </div>
    </div>
  );
};

export default CartItem;
