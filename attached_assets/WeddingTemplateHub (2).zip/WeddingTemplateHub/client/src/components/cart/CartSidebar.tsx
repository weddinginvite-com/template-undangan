import { useEffect } from 'react';
import { useCart } from '@/context/CartContext';
import CartItem from './CartItem';
import { formatCurrency } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { cn } from '@/lib/utils';

const CartSidebar = () => {
  const { 
    cart, 
    isCartOpen, 
    closeCart, 
    getCartTotal
  } = useCart();

  // Lock body scroll when cart is open
  useEffect(() => {
    if (isCartOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [isCartOpen]);

  const cartTotal = getCartTotal();

  return (
    <div className={cn(
      "fixed top-0 right-0 h-full w-full md:w-96 bg-white shadow-lg transform transition-transform duration-300 ease-in-out z-50",
      isCartOpen ? "translate-x-0" : "translate-x-full"
    )}>
      <div className="h-full flex flex-col">
        <div className="p-6 border-b flex justify-between items-center">
          <h3 className="font-heading text-xl font-semibold text-secondary">Keranjang Belanja</h3>
          <button 
            className="text-secondary hover:text-primary"
            onClick={closeCart}
            aria-label="Close cart"
          >
            <i className="ri-close-line text-2xl"></i>
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6">
          {cart.length === 0 ? (
            <div className="text-center text-secondary-light py-12">
              <i className="ri-shopping-cart-line text-5xl mb-4 text-gray-300"></i>
              <p>Keranjang belanja Anda kosong</p>
            </div>
          ) : (
            <div className="space-y-4">
              {cart.map((item) => (
                <CartItem key={item.id} item={item} />
              ))}
            </div>
          )}
        </div>
        
        <div className="p-6 border-t">
          <div className="flex justify-between mb-4">
            <span className="font-medium text-secondary">Subtotal:</span>
            <span className="font-medium text-secondary">{formatCurrency(cartTotal)}</span>
          </div>
          
          <Button 
            asChild
            className="w-full bg-primary hover:bg-primary-dark text-white font-medium py-3 px-6 rounded-lg transition-colors mb-3"
            disabled={cart.length === 0}
          >
            <Link href="/checkout" onClick={closeCart}>
              Checkout
            </Link>
          </Button>
          
          <Button 
            variant="outline" 
            className="w-full border-primary text-primary hover:bg-primary/5 font-medium py-3 px-6 rounded-lg transition-colors"
            onClick={closeCart}
          >
            Lanjutkan Belanja
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CartSidebar;
