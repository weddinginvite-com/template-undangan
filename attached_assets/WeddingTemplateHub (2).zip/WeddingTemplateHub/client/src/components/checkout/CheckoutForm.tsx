import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useCart } from '@/context/CartContext';
import { formatCurrency } from '@/lib/utils';
import { apiRequest } from '@/lib/queryClient';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import SuccessModal from './SuccessModal';

const checkoutFormSchema = z.object({
  customerName: z.string().min(3, { message: 'Nama harus diisi minimal 3 karakter' }),
  customerEmail: z.string().email({ message: 'Format email tidak valid' }),
  customerPhone: z.string().min(10, { message: 'Nomor telepon harus diisi minimal 10 digit' }),
  paymentMethod: z.enum(['transfer', 'credit', 'ewallet'], {
    required_error: 'Pilih metode pembayaran',
  }),
});

type CheckoutFormValues = z.infer<typeof checkoutFormSchema>;

const CheckoutForm = () => {
  const { cart, getCartTotal, clearCart } = useCart();
  const { toast } = useToast();
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);

  const subtotal = getCartTotal();
  const tax = subtotal * 0.11;
  const total = subtotal + tax;

  const form = useForm<CheckoutFormValues>({
    resolver: zodResolver(checkoutFormSchema),
    defaultValues: {
      customerName: '',
      customerEmail: '',
      customerPhone: '',
      paymentMethod: 'transfer',
    },
  });

  const createOrder = useMutation({
    mutationFn: async (data: CheckoutFormValues) => {
      return apiRequest('POST', '/api/orders', {
        items: cart,
        total: total,
        customerName: data.customerName,
        customerEmail: data.customerEmail,
        customerPhone: data.customerPhone,
        paymentMethod: data.paymentMethod,
        createdAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      setIsSuccessModalOpen(true);
      clearCart();
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: `Gagal membuat pesanan: ${error}`,
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (data: CheckoutFormValues) => {
    if (cart.length === 0) {
      toast({
        title: 'Error',
        description: 'Keranjang belanja Anda kosong',
        variant: 'destructive',
      });
      return;
    }

    createOrder.mutate(data);
  };

  const handleCloseSuccessModal = () => {
    setIsSuccessModalOpen(false);
  };

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h4 className="font-heading text-lg font-semibold text-secondary mb-4">Detail Pesanan</h4>
          
          <div className="space-y-4 mb-6">
            {cart.map((item) => (
              <div key={item.id} className="flex justify-between items-center border-b pb-3">
                <div>
                  <h5 className="font-medium text-secondary">{item.name}</h5>
                  <p className="text-sm text-secondary-light">Qty: {item.quantity}</p>
                </div>
                <div className="font-medium text-secondary">{formatCurrency(item.price * item.quantity)}</div>
              </div>
            ))}
          </div>
          
          <div className="border-t pt-4">
            <div className="flex justify-between mb-2">
              <span className="text-secondary">Subtotal:</span>
              <span className="text-secondary">{formatCurrency(subtotal)}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-secondary">PPN (11%):</span>
              <span className="text-secondary">{formatCurrency(tax)}</span>
            </div>
            <div className="flex justify-between font-semibold">
              <span className="text-secondary">Total:</span>
              <span className="text-primary">{formatCurrency(total)}</span>
            </div>
          </div>
        </div>
        
        <div>
          <h4 className="font-heading text-lg font-semibold text-secondary mb-4">Informasi Pelanggan</h4>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 gap-4">
                <FormField
                  control={form.control}
                  name="customerName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-secondary font-medium">Nama Lengkap</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="customerEmail"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-secondary font-medium">Email</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          type="email"
                          className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="customerPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-secondary font-medium">Nomor Telepon</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          type="tel"
                          className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div>
                <h4 className="font-heading text-lg font-semibold text-secondary mb-4">Metode Pembayaran</h4>
                
                <FormField
                  control={form.control}
                  name="paymentMethod"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="space-y-3"
                        >
                          <div className="border rounded-lg p-3 flex items-center">
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="transfer" id="payment-transfer" />
                              </FormControl>
                              <FormLabel className="flex items-center font-normal cursor-pointer" htmlFor="payment-transfer">
                                <i className="ri-bank-line text-xl mr-2 text-secondary"></i>
                                <span>Transfer Bank</span>
                              </FormLabel>
                            </FormItem>
                          </div>
                          
                          <div className="border rounded-lg p-3 flex items-center">
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="credit" id="payment-credit" />
                              </FormControl>
                              <FormLabel className="flex items-center font-normal cursor-pointer" htmlFor="payment-credit">
                                <i className="ri-bank-card-line text-xl mr-2 text-secondary"></i>
                                <span>Kartu Kredit</span>
                              </FormLabel>
                            </FormItem>
                          </div>
                          
                          <div className="border rounded-lg p-3 flex items-center">
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="ewallet" id="payment-ewallet" />
                              </FormControl>
                              <FormLabel className="flex items-center font-normal cursor-pointer" htmlFor="payment-ewallet">
                                <i className="ri-wallet-line text-xl mr-2 text-secondary"></i>
                                <span>E-Wallet</span>
                              </FormLabel>
                            </FormItem>
                          </div>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-primary hover:bg-primary-dark text-white font-medium py-3 px-6 rounded-lg transition-colors"
                disabled={createOrder.isPending}
              >
                {createOrder.isPending ? 'Memproses...' : 'Bayar Sekarang'}
              </Button>
            </form>
          </Form>
        </div>
      </div>
      
      <SuccessModal isOpen={isSuccessModalOpen} onClose={handleCloseSuccessModal} />
    </>
  );
};

export default CheckoutForm;
