import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

interface SuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const SuccessModal = ({ isOpen, onClose }: SuccessModalProps) => {
  const [_, setLocation] = useLocation();

  const handleGoHome = () => {
    onClose();
    setLocation('/');
  };

  // Automatically close after 10 seconds and redirect to home
  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (isOpen) {
      timer = setTimeout(() => {
        handleGoHome();
      }, 10000);
    }
    
    return () => {
      clearTimeout(timer);
    };
  }, [isOpen]);

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="text-center p-8 max-w-md">
        <div className="text-green-500 mb-4">
          <i className="ri-checkbox-circle-line text-6xl"></i>
        </div>
        <h3 className="font-heading text-2xl font-semibold text-secondary mb-2">Pembayaran Berhasil!</h3>
        <p className="text-secondary-light mb-6">
          Terima kasih telah melakukan pembelian. Detail pesanan telah dikirimkan ke email Anda.
        </p>
        <Button 
          className="w-full bg-primary hover:bg-primary-dark text-white font-medium py-3 px-6 rounded-lg transition-colors"
          onClick={handleGoHome}
        >
          Kembali ke Beranda
        </Button>
      </DialogContent>
    </Dialog>
  );
};

export default SuccessModal;
