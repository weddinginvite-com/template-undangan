import { useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

const contactFormSchema = z.object({
  name: z.string().min(3, { message: 'Nama harus diisi minimal 3 karakter' }),
  email: z.string().email({ message: 'Format email tidak valid' }),
  subject: z.string().min(5, { message: 'Subjek harus diisi minimal 5 karakter' }),
  message: z.string().min(10, { message: 'Pesan harus diisi minimal 10 karakter' }),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

const ContactForm = () => {
  const { toast } = useToast();

  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: '',
      email: '',
      subject: '',
      message: '',
    },
  });

  const sendMessage = useMutation({
    mutationFn: async (data: ContactFormValues) => {
      return apiRequest('POST', '/api/messages', {
        ...data,
        createdAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      toast({
        title: 'Pesan terkirim',
        description: 'Terima kasih telah menghubungi kami. Kami akan segera merespons pesan Anda.',
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: `Gagal mengirim pesan: ${error}`,
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (data: ContactFormValues) => {
    sendMessage.mutate(data);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="bg-accent p-8 rounded-xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="block text-secondary font-medium mb-2">Nama Lengkap</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors" 
                    placeholder="Nama Anda"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="block text-secondary font-medium mb-2">Email</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    type="email"
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors" 
                    placeholder="email@example.com"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="subject"
          render={({ field }) => (
            <FormItem className="mb-6">
              <FormLabel className="block text-secondary font-medium mb-2">Subjek</FormLabel>
              <FormControl>
                <Input 
                  {...field} 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors" 
                  placeholder="Subjek pesan Anda"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="message"
          render={({ field }) => (
            <FormItem className="mb-6">
              <FormLabel className="block text-secondary font-medium mb-2">Pesan</FormLabel>
              <FormControl>
                <Textarea 
                  {...field} 
                  rows={5}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors resize-none" 
                  placeholder="Tulis pesan Anda di sini..."
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <Button 
          type="submit" 
          className="w-full bg-primary hover:bg-primary-dark text-white font-medium py-3 px-6 rounded-lg transition-colors"
          disabled={sendMessage.isPending}
        >
          {sendMessage.isPending ? 'Mengirim...' : 'Kirim Pesan'}
        </Button>
      </form>
    </Form>
  );
};

export default ContactForm;
