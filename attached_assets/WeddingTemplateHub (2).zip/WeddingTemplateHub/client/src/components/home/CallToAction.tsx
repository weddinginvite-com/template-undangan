import { Link } from 'wouter';

const CallToAction = () => {
  return (
    <section className="py-20 bg-accent relative overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <div className="bg-primary/10 rounded-2xl p-8 md:p-12 max-w-5xl mx-auto text-center">
          <h6 className="font-script text-primary text-2xl mb-2">Mulai Sekarang</h6>
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-secondary mb-6">
            Buat Undangan Pernikahan Digital Anda
          </h2>
          <p className="text-secondary-light mb-8 max-w-2xl mx-auto">
            Dapatkan template undangan pernikahan digital yang elegan dan personal untuk momen spesial Anda. Mudah digunakan dan diakses oleh semua tamu undangan.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/templates">
              <span className="bg-primary hover:bg-primary-dark text-white font-medium py-3 px-8 rounded-lg transition-colors cursor-pointer inline-block">
                Pilih Template
              </span>
            </Link>
            <Link href="/contact">
              <span className="bg-white border border-primary text-primary hover:bg-accent-dark font-medium py-3 px-8 rounded-lg transition-colors cursor-pointer inline-block">
                Hubungi Kami
              </span>
            </Link>
          </div>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute top-20 left-10 w-24 h-24 bg-primary/5 rounded-full"></div>
      <div className="absolute bottom-10 right-10 w-32 h-32 bg-primary/5 rounded-full"></div>
    </section>
  );
};

export default CallToAction;
