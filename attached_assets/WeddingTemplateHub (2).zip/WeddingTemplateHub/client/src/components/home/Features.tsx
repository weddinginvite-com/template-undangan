const Features = () => {
  const features = [
    {
      icon: "ri-device-line",
      title: "Responsif di Semua Perangkat",
      description: "Template undangan kami dapat diakses dengan sempurna di semua perangkat, mulai dari smartphone hingga laptop."
    },
    {
      icon: "ri-gallery-line",
      title: "Galeri Foto & Video",
      description: "Tampilkan momen berharga Anda melalui galeri foto dan video yang dapat disesuaikan."
    },
    {
      icon: "ri-map-pin-line",
      title: "Peta Lokasi Terintegrasi",
      description: "Sertakan lokasi acara dengan peta interaktif agar tamu dapat dengan mudah menemukan tempat acara."
    },
    {
      icon: "ri-message-2-line",
      title: "Ucapan & RSVP",
      description: "Fitur RSVP online dan kolom ucapan yang memudahkan tamu untuk mengonfirmasi kehadiran dan memberikan doa restu."
    },
    {
      icon: "ri-gift-line",
      title: "Amplop Digital",
      description: "Terima hadiah pernikahan secara digital melalui fitur amplop digital yang terintegrasi dengan rekening bank."
    },
    {
      icon: "ri-music-line",
      title: "Background Musik",
      description: "Tambahkan lagu favorit Anda sebagai musik latar untuk menciptakan suasana yang lebih romantis."
    }
  ];

  return (
    <section id="fitur" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h6 className="font-script text-primary text-2xl mb-2">Kelebihan Kami</h6>
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-secondary">Fitur Unggulan Template</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-accent p-8 rounded-lg text-center">
              <div className="bg-primary/10 w-16 h-16 mx-auto rounded-full flex items-center justify-center mb-6">
                <i className={`${feature.icon} text-primary text-3xl`}></i>
              </div>
              <h3 className="font-heading text-xl font-semibold text-secondary mb-3">{feature.title}</h3>
              <p className="text-secondary-light">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
