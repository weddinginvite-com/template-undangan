import { Link } from 'wouter';

const Hero = () => {
  return (
    <section id="beranda" className="relative bg-accent pt-16 pb-24 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold text-secondary mb-6">
              Template Undangan Pernikahan Digital yang Elegan
            </h1>
            <p className="text-lg md:text-xl text-secondary-light mb-8">
              Jadikan momen pernikahan Anda spesial dengan undangan digital yang indah dan personal.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/templates">
                <span className="bg-primary hover:bg-primary-dark text-white font-medium py-3 px-6 rounded-lg transition-colors text-center cursor-pointer inline-block">
                  Lihat Template
                </span>
              </Link>
              <Link href="/#fitur">
                <span className="bg-white border border-primary text-primary hover:bg-accent-dark font-medium py-3 px-6 rounded-lg transition-colors text-center cursor-pointer inline-block">
                  Fitur Unggulan
                </span>
              </Link>
            </div>
          </div>
          
          <div className="md:w-1/2 relative">
            <img 
              src="https://images.unsplash.com/photo-1607190074257-dd4b7af0309f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
              alt="Contoh Template Undangan Pernikahan" 
              className="w-full h-auto rounded-lg shadow-xl z-10 relative"
            />
            <div className="absolute -bottom-6 -right-6 w-4/5 h-full bg-primary/10 rounded-lg -z-10"></div>
          </div>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full -translate-y-1/2 translate-x-1/3"></div>
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-primary/5 rounded-full translate-y-1/3 -translate-x-1/4"></div>
    </section>
  );
};

export default Hero;
