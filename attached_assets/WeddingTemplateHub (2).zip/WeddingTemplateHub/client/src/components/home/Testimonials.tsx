const Testimonials = () => {
  const testimonials = [
    {
      rating: 5,
      content: "Template undangan digital ini sangat membantu. Desainnya elegan dan fiturnya lengkap. Semua tamu kami terkesan dengan undangan pernikahan kami.",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&q=80",
      name: "Anita Wijaya",
      template: "Template Elegant Gold"
    },
    {
      rating: 5,
      content: "Saya sangat merekomendasikan template ini. Prosesnya mudah, hasilnya profesional, dan dukungan tim sangat responsif!",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&q=80",
      name: "Budi Santoso",
      template: "Template Minimalist Charm"
    },
    {
      rating: 4.5,
      content: "Fitur RSVP dan amplop digital sangat memudahkan kami mengatur pernikahan. Template pernikahan ini sangat worth it!",
      avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&q=80",
      name: "Dina Permata",
      template: "Template Floral Bliss"
    }
  ];

  const renderStars = (rating: number) => {
    return (
      <div className="flex gap-1 mb-4">
        {[...Array(5)].map((_, i) => {
          if (i < Math.floor(rating)) {
            return <i key={i} className="ri-star-fill text-yellow-400"></i>;
          } else if (i === Math.floor(rating) && rating % 1 !== 0) {
            return <i key={i} className="ri-star-half-fill text-yellow-400"></i>;
          } else {
            return <i key={i} className="ri-star-line text-yellow-400"></i>;
          }
        })}
      </div>
    );
  };

  return (
    <section id="testimoni" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h6 className="font-script text-primary text-2xl mb-2">Apa Kata Mereka</h6>
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-secondary">Testimoni Pelanggan</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-accent p-8 rounded-lg">
              {renderStars(testimonial.rating)}
              <p className="text-secondary-light mb-6 italic">
                "{testimonial.content}"
              </p>
              <div className="flex items-center">
                <img 
                  src={testimonial.avatar} 
                  alt={`Foto Profil ${testimonial.name}`}
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-heading text-base font-semibold text-secondary">{testimonial.name}</h4>
                  <p className="text-secondary-light text-sm">{testimonial.template}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
