import { Link } from 'wouter';

const Footer = () => {
  return (
    <footer className="bg-secondary text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <div>
            <Link href="/">
              <span className="font-script text-white text-3xl mb-6 inline-block cursor-pointer">EleganVite</span>
            </Link>
            <p className="text-gray-300 mb-6">
              Menyediakan template undangan pernikahan digital berkualitas tinggi dengan desain elegan dan fitur lengkap.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <i className="ri-instagram-line text-xl"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <i className="ri-facebook-fill text-xl"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <i className="ri-twitter-fill text-xl"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <i className="ri-whatsapp-line text-xl"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-heading text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li>
                <Link href="/">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Beranda</span>
                </Link>
              </li>
              <li>
                <Link href="/templates">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Template</span>
                </Link>
              </li>
              <li>
                <Link href="/#fitur">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Fitur</span>
                </Link>
              </li>
              <li>
                <Link href="/#testimoni">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Testimoni</span>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Kontak</span>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-heading text-lg font-semibold mb-6">Template</h4>
            <ul className="space-y-3">
              <li>
                <Link href="/templates/1">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Elegant Gold</span>
                </Link>
              </li>
              <li>
                <Link href="/templates/2">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Floral Bliss</span>
                </Link>
              </li>
              <li>
                <Link href="/templates/3">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Minimalist Charm</span>
                </Link>
              </li>
              <li>
                <Link href="/templates/4">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Rustic Vintage</span>
                </Link>
              </li>
              <li>
                <Link href="/templates/5">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">Marble Luxury</span>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-heading text-lg font-semibold mb-6">Bantuan</h4>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">FAQ</a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">Kebijakan Privasi</a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">Syarat & Ketentuan</a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">Panduan Penggunaan</a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">Pembayaran</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8">
          <p className="text-center text-gray-400">
            &copy; {new Date().getFullYear()} EleganVite. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
