import { useEffect, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { loadFonts } from '@/lib/fonts';
import { useCart } from '@/context/CartContext';
import { cn } from '@/lib/utils';

const Header = () => {
  const [location] = useLocation();
  const { toggleCart, getCartCount } = useCart();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    loadFonts();

    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  const cartCount = getCartCount();

  return (
    <header className={cn(
      "sticky top-0 bg-white z-50 transition-shadow duration-300",
      isScrolled ? "shadow-md" : ""
    )}>
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <Link href="/">
            <span className="text-primary font-script text-3xl cursor-pointer">EleganVite</span>
          </Link>
        </div>
        
        <nav className="hidden md:flex items-center space-x-8">
          <Link href="/">
            <span className={cn(
              "font-body hover:text-primary transition-colors cursor-pointer",
              location === "/" ? "text-primary" : "text-secondary"
            )}>
              Beranda
            </span>
          </Link>
          <Link href="/templates">
            <span className={cn(
              "font-body hover:text-primary transition-colors cursor-pointer",
              location === "/templates" ? "text-primary" : "text-secondary"
            )}>
              Template
            </span>
          </Link>
          <Link href="/#fitur">
            <span className="font-body text-secondary hover:text-primary transition-colors cursor-pointer">
              Fitur
            </span>
          </Link>
          <Link href="/#testimoni">
            <span className="font-body text-secondary hover:text-primary transition-colors cursor-pointer">
              Testimoni
            </span>
          </Link>
          <Link href="/contact">
            <span className={cn(
              "font-body hover:text-primary transition-colors cursor-pointer",
              location === "/contact" ? "text-primary" : "text-secondary"
            )}>
              Kontak
            </span>
          </Link>
        </nav>
        
        <div className="flex items-center space-x-4">
          <button 
            className="flex items-center text-secondary hover:text-primary"
            aria-label="Search"
          >
            <i className="ri-search-line text-xl"></i>
          </button>
          <button 
            className="relative flex items-center text-secondary hover:text-primary" 
            onClick={toggleCart}
            aria-label="Shopping cart"
          >
            <i className="ri-shopping-cart-line text-xl"></i>
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {cartCount > 99 ? '99+' : cartCount}
              </span>
            )}
          </button>
          <button 
            className="md:hidden flex items-center text-secondary" 
            onClick={toggleMobileMenu}
            aria-label="Menu"
          >
            <i className={`text-2xl ${isMobileMenuOpen ? 'ri-close-line' : 'ri-menu-line'}`}></i>
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <div className={`md:hidden bg-white px-4 py-2 shadow-inner ${isMobileMenuOpen ? 'block' : 'hidden'}`}>
        <nav className="flex flex-col space-y-3 pb-4">
          <Link href="/">
            <span 
              className="font-body text-secondary py-2 border-b border-gray-100 block cursor-pointer"
              onClick={closeMobileMenu}
            >
              Beranda
            </span>
          </Link>
          <Link href="/templates">
            <span 
              className="font-body text-secondary py-2 border-b border-gray-100 block cursor-pointer"
              onClick={closeMobileMenu}
            >
              Template
            </span>
          </Link>
          <Link href="/#fitur">
            <span 
              className="font-body text-secondary py-2 border-b border-gray-100 block cursor-pointer"
              onClick={closeMobileMenu}
            >
              Fitur
            </span>
          </Link>
          <Link href="/#testimoni">
            <span 
              className="font-body text-secondary py-2 border-b border-gray-100 block cursor-pointer"
              onClick={closeMobileMenu}
            >
              Testimoni
            </span>
          </Link>
          <Link href="/contact">
            <span 
              className="font-body text-secondary py-2 block cursor-pointer"
              onClick={closeMobileMenu}
            >
              Kontak
            </span>
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;
