import { useState } from 'react';
import { Link } from 'wouter';
import { Template } from '@shared/schema';
import { calculateRatingStars, formatCurrency } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/context/CartContext';

interface TemplateCardProps {
  template: Template;
  onPreview: (template: Template) => void;
}

const TemplateCard = ({ template, onPreview }: TemplateCardProps) => {
  const { addToCart } = useCart();
  const stars = calculateRatingStars(template.rating);

  const handlePreview = (e: React.MouseEvent) => {
    e.preventDefault();
    onPreview(template);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    addToCart(template);
  };

  return (
    <div className="card-hover bg-white rounded-xl overflow-hidden shadow-md" data-category={template.category}>
      <div className="relative">
        <img 
          src={template.imageUrl} 
          alt={`Template ${template.name}`}
          className="w-full h-72 object-cover object-center"
        />
        <div className="absolute top-4 right-4 flex flex-col gap-2">
          {template.isBestseller && (
            <Badge variant="default" className="py-1 px-3">Terlaris</Badge>
          )}
          {template.isNew && (
            <Badge variant="info" className="py-1 px-3">Baru</Badge>
          )}
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="font-heading text-xl font-semibold text-secondary mb-2">{template.name}</h3>
        <p className="text-secondary-light text-sm mb-4">
          {template.description.length > 80 
            ? `${template.description.substring(0, 80)}...` 
            : template.description}
        </p>
        
        <div className="flex justify-between items-center mb-4">
          <div>
            <span className="text-primary font-semibold text-lg">{formatCurrency(template.price)}</span>
          </div>
          <div className="flex gap-1 items-center">
            {stars.map((star, index) => (
              <i 
                key={index} 
                className={`${
                  star === 'full' ? 'ri-star-fill' : 
                  star === 'half' ? 'ri-star-half-fill' : 
                  'ri-star-line'
                } text-yellow-400`}
              ></i>
            ))}
            <span className="text-xs text-gray-500 ml-1">({template.reviews})</span>
          </div>
        </div>
        
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            className="flex-1 border-primary text-primary hover:bg-primary/5"
            onClick={handlePreview}
          >
            Preview
          </Button>
          <Button 
            variant="default" 
            className="flex-1 bg-primary hover:bg-primary-dark"
            onClick={handleAddToCart}
          >
            + Keranjang
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TemplateCard;
