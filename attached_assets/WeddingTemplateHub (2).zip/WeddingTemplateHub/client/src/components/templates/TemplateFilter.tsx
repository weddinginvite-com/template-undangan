import { useState } from 'react';
import { TemplateCategory, templateCategories } from '@shared/schema';
import { cn } from '@/lib/utils';

interface TemplateFilterProps {
  onFilterChange: (category: string) => void;
  activeCategory: string;
}

const TemplateFilter = ({ onFilterChange, activeCategory }: TemplateFilterProps) => {
  return (
    <div className="flex flex-wrap justify-center gap-3 mb-10">
      <button 
        className={cn(
          "px-5 py-2 rounded-full border border-primary text-sm font-medium transition-colors",
          activeCategory === 'all' ? "bg-primary text-white" : "text-primary hover:bg-primary/5"
        )}
        onClick={() => onFilterChange('all')}
      >
        Semua
      </button>
      
      {templateCategories.map((category) => (
        <button 
          key={category}
          className={cn(
            "px-5 py-2 rounded-full border border-primary text-sm font-medium transition-colors",
            activeCategory === category ? "bg-primary text-white" : "text-primary hover:bg-primary/5"
          )}
          onClick={() => onFilterChange(category)}
        >
          {category.charAt(0).toUpperCase() + category.slice(1)}
        </button>
      ))}
    </div>
  );
};

export default TemplateFilter;
