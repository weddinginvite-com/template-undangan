import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Template } from '@shared/schema';
import TemplateCard from './TemplateCard';
import TemplateFilter from './TemplateFilter';
import TemplatePreview from './TemplatePreview';
import { Button } from '@/components/ui/button';

interface TemplateGridProps {
  limit?: number;
  showAllLink?: boolean;
}

const TemplateGrid = ({ limit, showAllLink = false }: TemplateGridProps) => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [filteredTemplates, setFilteredTemplates] = useState<Template[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  const { data: templates = [], isLoading, error } = useQuery<Template[]>({
    queryKey: ['/api/templates'],
  });

  useEffect(() => {
    if (!templates || !templates.length) return;
    
    const filterTemplates = () => {
      if (activeCategory === 'all') {
        return limit ? templates.slice(0, limit) : templates;
      } else {
        const filtered = templates.filter((template: Template) => template.category === activeCategory);
        return limit ? filtered.slice(0, limit) : filtered;
      }
    };
    
    setFilteredTemplates(filterTemplates());
  }, [templates, activeCategory, limit]);

  const handleFilterChange = (category: string) => {
    setActiveCategory(category);
  };

  const handlePreview = (template: Template) => {
    setSelectedTemplate(template);
    setIsPreviewOpen(true);
  };

  const handleClosePreview = () => {
    setIsPreviewOpen(false);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-20">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-20">
        <p className="text-destructive">Gagal memuat template. Silakan coba lagi.</p>
      </div>
    );
  }

  return (
    <div>
      <TemplateFilter 
        onFilterChange={handleFilterChange} 
        activeCategory={activeCategory} 
      />
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredTemplates.map((template: Template) => (
          <TemplateCard 
            key={template.id} 
            template={template} 
            onPreview={handlePreview} 
          />
        ))}
      </div>
      
      {showAllLink && limit && templates.length > limit && (
        <div className="text-center mt-12">
          <Button asChild className="bg-primary hover:bg-primary-dark text-white font-medium py-3 px-6 rounded-lg transition-colors inline-flex items-center gap-2">
            <span onClick={() => window.location.href = '/templates'} className="cursor-pointer">
              Lihat Semua Template
              <i className="ri-arrow-right-line"></i>
            </span>
          </Button>
        </div>
      )}
      
      {selectedTemplate && (
        <TemplatePreview 
          template={selectedTemplate}
          isOpen={isPreviewOpen}
          onClose={handleClosePreview}
        />
      )}
    </div>
  );
};

export default TemplateGrid;
