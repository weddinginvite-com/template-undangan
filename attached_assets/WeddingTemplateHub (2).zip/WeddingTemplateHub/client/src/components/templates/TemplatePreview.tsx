import { useState } from 'react';
import { Template } from '@shared/schema';
import { formatCurrency, calculateRatingStars } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useCart } from '@/context/CartContext';

interface TemplatePreviewProps {
  template: Template;
  isOpen: boolean;
  onClose: () => void;
}

const TemplatePreview = ({ template, isOpen, onClose }: TemplatePreviewProps) => {
  const { addToCart } = useCart();
  const [selectedThumbnail, setSelectedThumbnail] = useState(0);
  const stars = calculateRatingStars(template.rating);

  const handleAddToCart = () => {
    addToCart(template);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl font-semibold text-secondary">
            Preview Template
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-4">
          <div>
            <div className="rounded-lg overflow-hidden h-80 bg-gray-100 flex items-center justify-center mb-4">
              <img 
                src={template.thumbnails[selectedThumbnail]} 
                alt={template.name} 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex gap-2 mb-4">
              {template.thumbnails.map((thumbnail, index) => (
                <div 
                  key={index}
                  className={`w-20 h-20 rounded-md overflow-hidden cursor-pointer border-2 ${
                    index === selectedThumbnail ? 'border-primary' : 'border-transparent'
                  }`}
                  onClick={() => setSelectedThumbnail(index)}
                >
                  <img 
                    src={thumbnail} 
                    alt={`Thumbnail ${index + 1}`} 
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="font-heading text-2xl font-semibold text-secondary mb-2">
              {template.name}
            </h4>
            
            <div className="flex items-center gap-2 mb-4">
              <div className="flex gap-1">
                {stars.map((star, index) => (
                  <i 
                    key={index} 
                    className={`${
                      star === 'full' ? 'ri-star-fill' : 
                      star === 'half' ? 'ri-star-half-fill' : 
                      'ri-star-line'
                    } text-yellow-400`}
                  ></i>
                ))}
              </div>
              <span className="text-secondary-light">({template.reviews} reviews)</span>
            </div>
            
            <div className="mb-4">
              <span className="text-primary font-semibold text-2xl">
                {formatCurrency(template.price)}
              </span>
            </div>
            
            <div className="border-t border-b py-4 mb-4">
              <h5 className="font-heading font-semibold text-secondary mb-3">Fitur Template:</h5>
              <ul className="space-y-2">
                {template.features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <i className="ri-checkbox-circle-line text-primary"></i>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="mb-6">
              <h5 className="font-heading font-semibold text-secondary mb-3">Deskripsi:</h5>
              <p className="text-secondary-light">
                {template.description}
              </p>
            </div>
            
            <Button 
              className="w-full bg-primary hover:bg-primary-dark text-white font-medium py-3 px-6 rounded-lg transition-colors mb-3"
              onClick={handleAddToCart}
            >
              Tambahkan ke Keranjang
            </Button>
            
            <Button 
              variant="outline" 
              className="w-full border-primary text-primary hover:bg-primary/5 font-medium py-3 px-6 rounded-lg transition-colors"
            >
              Lihat Demo Lengkap
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TemplatePreview;
