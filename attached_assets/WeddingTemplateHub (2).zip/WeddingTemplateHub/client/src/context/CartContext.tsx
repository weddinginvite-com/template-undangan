import React, { createContext, useState, useContext, useEffect } from 'react';
import { CartItem, Template } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

interface CartContextType {
  cart: CartItem[];
  isCartOpen: boolean;
  addToCart: (template: Template, quantity?: number) => void;
  removeFromCart: (templateId: number) => void;
  updateQuantity: (templateId: number, quantity: number) => void;
  clearCart: () => void;
  toggleCart: () => void;
  closeCart: () => void;
  openCart: () => void;
  getCartTotal: () => number;
  getCartCount: () => number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const { toast } = useToast();

  // Load cart from localStorage on initial render
  useEffect(() => {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      try {
        setCart(JSON.parse(savedCart));
      } catch (error) {
        console.error('Failed to parse cart from localStorage', error);
      }
    }
  }, []);

  // Save cart to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (template: Template, quantity = 1) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === template.id);
      
      if (existingItem) {
        toast({
          title: "Jumlah diperbarui",
          description: `${template.name} sudah ada di keranjang, jumlah diperbarui.`
        });
        
        return prevCart.map(item => 
          item.id === template.id 
            ? { ...item, quantity: item.quantity + quantity } 
            : item
        );
      } else {
        toast({
          title: "Ditambahkan ke keranjang",
          description: `${template.name} berhasil ditambahkan ke keranjang.`
        });
        
        return [
          ...prevCart,
          {
            id: template.id,
            name: template.name,
            price: template.price,
            imageUrl: template.imageUrl,
            quantity
          }
        ];
      }
    });
  };

  const removeFromCart = (templateId: number) => {
    setCart(prevCart => prevCart.filter(item => item.id !== templateId));
    
    toast({
      title: "Item dihapus",
      description: "Item berhasil dihapus dari keranjang."
    });
  };

  const updateQuantity = (templateId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(templateId);
      return;
    }
    
    setCart(prevCart => 
      prevCart.map(item => 
        item.id === templateId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
    toast({
      title: "Keranjang dikosongkan",
      description: "Semua item berhasil dihapus dari keranjang."
    });
  };

  const toggleCart = () => {
    setIsCartOpen(prev => !prev);
  };

  const closeCart = () => {
    setIsCartOpen(false);
  };

  const openCart = () => {
    setIsCartOpen(true);
  };

  const getCartTotal = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const getCartCount = () => {
    return cart.reduce((count, item) => count + item.quantity, 0);
  };

  return (
    <CartContext.Provider value={{
      cart,
      isCartOpen,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      toggleCart,
      closeCart,
      openCart,
      getCartTotal,
      getCartCount
    }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = (): CartContextType => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
