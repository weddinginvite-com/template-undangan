// Import Google Fonts through a link in the head instead of through CSS imports
// This script adds the links to the document head
export function loadFonts() {
  // Playfair Display, Raleway, and Great Vibes fonts
  const fontLink = document.createElement('link');
  fontLink.rel = 'stylesheet';
  fontLink.href = 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Raleway:wght@300;400;500;600&family=Great+Vibes&display=swap';
  document.head.appendChild(fontLink);

  // Remixicon for icons
  const iconLink = document.createElement('link');
  iconLink.rel = 'stylesheet';
  iconLink.href = 'https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css';
  document.head.appendChild(iconLink);
}

// Call this function in a useEffect in the main layout component
