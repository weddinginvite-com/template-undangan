import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format currency to IDR
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('id-ID', { 
    style: 'currency', 
    currency: 'IDR', 
    minimumFractionDigits: 0 
  }).format(amount);
}

// Calculate rating stars - returns array with filled, half, and empty stars
export function calculateRatingStars(rating: number): ('full' | 'half' | 'empty')[] {
  const stars: ('full' | 'half' | 'empty')[] = [];
  // Convert rating from 0-50 scale to 0-5 scale
  const normalizedRating = rating / 10;
  
  for (let i = 1; i <= 5; i++) {
    if (i <= Math.floor(normalizedRating)) {
      stars.push('full');
    } else if (i - 0.5 <= normalizedRating) {
      stars.push('half');
    } else {
      stars.push('empty');
    }
  }
  
  return stars;
}

// Check if an element is visible in viewport
export function isElementInViewport(el: Element): boolean {
  const rect = el.getBoundingClientRect();
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
}
